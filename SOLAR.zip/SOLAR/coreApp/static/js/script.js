$(document).ready( function () {
    $('#reports').DataTable();
} );