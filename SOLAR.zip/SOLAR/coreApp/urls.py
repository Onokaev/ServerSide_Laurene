from django.urls import path
from . import views

urlpatterns = [
    path('', views.userlogin, name='userlogin'),
    path('home', views.home, name='home'),
    path('logout', views.userlogout, name='userlogout'),
]