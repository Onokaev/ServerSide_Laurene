from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from django.shortcuts import render, redirect
from . import models

# login form
class LoginUserForm(AuthenticationForm):
    class Meta:
        model = User
        fields = "__all__"


# login request
def userlogin(request):
    form = LoginUserForm()

    if request.method == "POST":
        user = authenticate(request, username=request.POST['username'], password=request.POST['password'])
        if user is None:
            error = True  # set an error due to authentication errors
            return render(request, 'login.html', {'form': form, 'error': error})
        else:
            login(request, user) # login the user 
            return redirect('home')
    return render(request, 'login.html', {'form': form})


# logout request
def userlogout(request):
    if request.method == "POST":
        logout(request)
        return redirect('userlogin')


def home(request):
    print(request)
    records = models.SocDoc.objects.values()
    return render(request, 'home.html', {"records": list(records)})
